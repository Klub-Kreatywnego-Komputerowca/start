# Podstawy rysowania

Tworzenie własnego bohatera.

### Wstęp

Po co programować?

### Rozpoczęcie pracy

Wchodzimy na stronę: 

[p5.js Web Editor](https://editor.p5js.org/)

![Untitled](Podstawy%20rysowania%2038263063c2cc45eaa21025cfe92d02e7/Untitled.png)

### Okno programu

Podzielone jest na kilka części. Nas interesuje obszar zawierający linie kodu:

![Untitled](Podstawy%20rysowania%2038263063c2cc45eaa21025cfe92d02e7/Untitled%201.png)

To w nim użyjemy pierwszych komend. Efekt działania naszego kodu możemy zobaczymy w oknie z prawej strony podpisanym “P*review”.*

W naszym kodzie mamy zdeklarowane kilka funkcji. Czym jest funkcja i  czego służą dowiemy się później. 

## Podstawowe kształty

## Współrzędne kształtów

## Obramowanie i wypełnienie

## Kolory

## Zadanie

### Narysowanie miski i jabłka